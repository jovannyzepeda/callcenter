<?php

require_once 'src/Client.php';
require_once 'src/WeglotException.php';