<?php
namespace Weglot;

class WeglotException extends \Exception
{
}
